// Popup script
const TARGET_LANGS = [
  ["en", "English"], ["es", "Spanish"], ["fr", "French"], ["de", "German"],
  ["it", "Italian"], ["pt", "Portuguese"], ["ru", "Russian"], ["ja", "Japanese"],
  ["ko", "Korean"], ["zh", "Chinese (Simplified)"], ["zh-TW", "Chinese (Traditional)"],
  ["ar", "Arabic"], ["hi", "Hindi"], ["tr", "Turkish"], ["vi", "Vietnamese"],
  ["th", "Thai"], ["nl", "Dutch"], ["pl", "Polish"], ["sv", "Swedish"]
];

const OCR_LANGS = [
  ["eng", "English"], ["spa", "Spanish"], ["fra", "French"], ["deu", "German"],
  ["ita", "Italian"], ["por", "Portuguese"], ["rus", "Russian"], ["jpn", "Japanese"],
  ["kor", "Korean"], ["chi_sim", "Chinese (Simplified)"], ["chi_tra", "Chinese (Traditional)"],
  ["ara", "Arabic"], ["hin", "Hindi"], ["tur", "Turkish"], ["vie", "Vietnamese"],
  ["tha", "Thai"], ["nld", "Dutch"], ["pol", "Polish"]
];

function fillSelect(el, options) {
  for (const [v, label] of options) {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = label;
    el.appendChild(opt);
  }
}

(async function init() {
  const targetSel = document.getElementById("targetLang");
  const ocrSel = document.getElementById("ocrLang");
  const engineSel = document.getElementById("engine");

  fillSelect(targetSel, TARGET_LANGS);
  fillSelect(ocrSel, OCR_LANGS);

  const settings = await chrome.storage.sync.get(null);
  if (settings.targetLang) targetSel.value = settings.targetLang;
  if (settings.ocrLang) ocrSel.value = settings.ocrLang;
  if (settings.engine) engineSel.value = settings.engine;

  for (const el of [targetSel, ocrSel, engineSel]) {
    el.addEventListener("change", () => {
      chrome.storage.sync.set({
        targetLang: targetSel.value,
        ocrLang: ocrSel.value,
        engine: engineSel.value
      });
    });
  }

  document.getElementById("translateAll").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      chrome.tabs.sendMessage(tab.id, { type: "TRANSLATE_ALL_IMAGES" });
      window.close();
    }
  });

  document.getElementById("openOptions").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
})();
