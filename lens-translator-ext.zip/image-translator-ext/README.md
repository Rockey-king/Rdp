# Lens Translator — Image Text Translator Extension

A browser extension that extracts text from images using OCR and overlays a translation in your chosen language. Like Google Lens, but as a browser extension that works on **Firefox for Android**, Firefox desktop, and Chromium browsers.

## How it works

```
  ┌──────────┐    ┌─────────┐    ┌────────────┐    ┌──────────┐
  │  Image   │ →  │   OCR   │ →  │ Translate  │ →  │ Overlay  │
  │ (pixels) │    │ (Tesse- │    │  (Google/  │    │ (canvas  │
  │          │    │  ract)  │    │  DeepL/AI) │    │  div)    │
  └──────────┘    └─────────┘    └────────────┘    └──────────┘
```

You were right — it **is** pixel-related. The pipeline:

1. Grab the image bytes.
2. Run **Tesseract.js** OCR locally (in WebAssembly) to extract words + bounding boxes from the pixels.
3. Group words into lines, send each line to a translation API.
4. Render translated text as positioned overlays on top of the original image.

## Features

- **Long-press on Android** any image to translate (also right-click on desktop).
- **4 translation engines**: Google Translate (free, no key), DeepL, OpenAI, Claude.
- **OCR runs locally** — image pixels never leave your device.
- **15+ OCR languages** including Japanese, Chinese, Korean, Arabic, Hindi, Thai.
- **20 target languages** for translation.
- "Translate all images on this page" button.

## Project structure

```
image-translator-ext/
├── manifest.json          # MV3 manifest, Firefox Android compatible
├── src/
│   ├── background.js      # Service worker: context menus, translation APIs
│   ├── content.js         # Runs on pages: OCR + overlay rendering
│   └── overlay.css        # Styles for the translation overlay
├── popup/                 # Toolbar popup (language picker, engine picker)
├── options/               # Settings page (API keys)
├── lib/                   # Tesseract.js + WASM core + language data (you add these)
└── icons/                 # Extension icons (you add these)
```

## What still needs to be done by Claude Code

I've built all the JavaScript / HTML / CSS. The remaining pieces are:

1. **Download Tesseract.js** into `lib/` (it's ~2 MB, can't be bundled into a chat).
2. **Generate icons** (16/32/48/128 px PNGs).
3. **Test on Firefox for Android** and fix any platform quirks.

A ready-to-paste Claude Code prompt is at the bottom of this README.

## Setup (manual, if not using Claude Code)

### 1. Install dependencies

```bash
cd image-translator-ext
mkdir -p lib/lang-data

# Download Tesseract.js v5 runtime files
curl -L https://unpkg.com/tesseract.js@5/dist/tesseract.min.js \
  -o lib/tesseract.min.js
curl -L https://unpkg.com/tesseract.js@5/dist/worker.min.js \
  -o lib/tesseract-worker.min.js
curl -L https://unpkg.com/tesseract.js-core@5/tesseract-core.wasm.js \
  -o lib/tesseract-core.wasm.js

# Download language data (English + whichever languages you need)
cd lib/lang-data
curl -LO https://tessdata.projectnaptha.com/4.0.0/eng.traineddata.gz
curl -LO https://tessdata.projectnaptha.com/4.0.0/jpn.traineddata.gz
curl -LO https://tessdata.projectnaptha.com/4.0.0/chi_sim.traineddata.gz
# Add more language data files as needed (one per OCR language you'll use)
cd ../..
```

### 2. Generate icons

You need `icons/icon-16.png`, `icon-32.png`, `icon-48.png`, `icon-128.png`. Any image editor works, or use ImageMagick:

```bash
# If you have a 512x512 source.png:
for size in 16 32 48 128; do
  magick source.png -resize ${size}x${size} icons/icon-${size}.png
done
```

### 3. Load on Firefox for Android

Firefox for Android requires extensions to be **signed by Mozilla** OR loaded via Firefox Nightly's debugging mode. Two options:

#### Option A — Firefox Nightly (easiest for development)

1. Install **Firefox Nightly for Android** from the Play Store.
2. Open Nightly → tap the menu → Settings → "About Firefox Nightly" → tap the logo 5 times to enable debug menu.
3. Go to Settings → "Install extension from file" (now visible).
4. Zip the `image-translator-ext/` folder contents into `extension.zip` (the manifest must be at the zip root).
5. Select that zip — done.

#### Option B — Sign with Mozilla and install on regular Firefox Android

1. Run `web-ext sign --api-key=... --api-secret=...` (see [Mozilla docs](https://extensionworkshop.com/documentation/publish/submitting-an-add-on/)).
2. Install the resulting `.xpi` file on regular Firefox for Android.

### 4. Load on desktop browsers (for testing)

- **Firefox desktop**: about:debugging → "This Firefox" → "Load Temporary Add-on" → pick `manifest.json`.
- **Chrome / Edge**: chrome://extensions → enable Developer Mode → "Load unpacked" → pick the folder.

## Usage

- **Android**: long-press any image → translation overlays appear.
- **Desktop**: right-click image → "Translate text in this image".
- **Bulk**: open the extension popup → "Translate all images on this page".
- **Settings**: popup → "Settings & API keys" to add DeepL/OpenAI/Claude keys.

## Privacy

- Image pixels are processed locally with Tesseract WebAssembly. They are never uploaded.
- The **extracted text** is sent to the translation API you choose. If you pick Google (default), text is sent to Google's public translate endpoint with no auth.
- API keys are stored in `chrome.storage.sync` (encrypted by browser, synced via your browser account if signed in).

## Known limitations

- Tesseract isn't as accurate as Google Vision API, especially on stylized or low-contrast text. If you need higher quality, swap in a cloud OCR (the OCR step is isolated in `runOcr()` in `content.js`).
- Vertical Japanese / Chinese text needs `--psm 5` (currently uses default mode 3). Edit `runOcr` if you need this.
- The free Google Translate endpoint is rate-limited and can break without warning. For production use, switch to DeepL or an LLM engine.
- The overlay uses a flat black-bar aesthetic; if you want the "inpainted" Google Lens look (translated text painted onto cleared background), you'd need a separate inpainting step — that's a much larger project.

## Next steps / ideas

- Cache OCR + translation results per image URL to avoid re-running on revisit.
- Add an inline mode where translated text is shown next to original without covering it.
- Support PDF images (would need a content script that runs in PDF viewer frames).

---

## Prompt for Claude Code

Paste this into Claude Code in your repo root after `git clone`-ing this project:

> I have a browser extension project for Firefox Android that translates text in images using OCR (Tesseract.js) and a translation API. The JavaScript, HTML, and CSS are all written. I need you to:
>
> 1. Read the `README.md` and the `manifest.json` to understand the project.
> 2. Create the `lib/` directory and download these files into it:
>    - `https://unpkg.com/tesseract.js@5/dist/tesseract.min.js` → `lib/tesseract.min.js`
>    - `https://unpkg.com/tesseract.js@5/dist/worker.min.js` → `lib/tesseract-worker.min.js`
>    - `https://unpkg.com/tesseract.js-core@5/tesseract-core.wasm.js` → `lib/tesseract-core.wasm.js`
> 3. Create `lib/lang-data/` and download `eng.traineddata.gz` from `https://tessdata.projectnaptha.com/4.0.0/`. Also download `jpn`, `chi_sim`, `kor`, `fra`, `deu`, `spa`, `rus`, `ara` traineddata.gz files.
> 4. Generate placeholder PNG icons at `icons/icon-{16,32,48,128}.png`. Use a simple gradient circle with the letter "L" centered, using ImageMagick or any tool you prefer. The aesthetic should match the popup gradient: `#1a73e8` to `#6c5ce7`.
> 5. Verify the manifest.json is valid by running `web-ext lint` if available, or by manually checking required fields.
> 6. Zip the entire project (with manifest at the zip root, NOT inside a subfolder): `cd image-translator-ext && zip -r ../lens-translator.zip . -x "*.git*" "node_modules/*"`.
> 7. Print instructions for loading on Firefox Nightly Android.
> 8. Run a syntax check on every `.js` file with `node --check` and report any errors.
> 9. Do NOT modify the existing source files (`src/`, `popup/`, `options/`, `manifest.json`) unless you find an actual bug — and if you do, explain it before fixing.
>
> When done, give me a checklist of what works and what I should test manually.

## License

MIT — do whatever you want with it.
