(async function init() {
  const settings = await chrome.storage.sync.get(null);
  const keys = settings.apiKeys || {};

  document.getElementById("deeplKey").value  = keys.deepl  || "";
  document.getElementById("openaiKey").value = keys.openai || "";
  document.getElementById("claudeKey").value = keys.claude || "";
  document.getElementById("autoDetect").checked = settings.autoDetectSource !== false;

  document.getElementById("save").addEventListener("click", async () => {
    await chrome.storage.sync.set({
      apiKeys: {
        deepl:  document.getElementById("deeplKey").value.trim(),
        openai: document.getElementById("openaiKey").value.trim(),
        claude: document.getElementById("claudeKey").value.trim()
      },
      autoDetectSource: document.getElementById("autoDetect").checked
    });
    const msg = document.getElementById("saveMsg");
    msg.textContent = "Saved ✓";
    setTimeout(() => (msg.textContent = ""), 2000);
  });
})();
