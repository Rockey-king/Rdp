// Background service worker
// Handles: context menu registration, image fetching (CORS workaround),
// translation API calls, settings persistence.

const DEFAULTS = {
  engine: "google",          // google | deepl | openai | claude
  targetLang: "en",
  ocrLang: "eng",            // Tesseract language code (eng, jpn, chi_sim, etc.)
  apiKeys: {
    deepl: "",
    openai: "",
    claude: ""
  },
  overlayStyle: "block",     // block | inline | sidebyside
  autoDetectSource: true
};

// ---------- Setup ----------
chrome.runtime.onInstalled.addListener(async () => {
  // Initialize defaults if empty
  const stored = await chrome.storage.sync.get(null);
  const merged = { ...DEFAULTS, ...stored };
  await chrome.storage.sync.set(merged);

  chrome.contextMenus.create({
    id: "translate-image",
    title: "Translate text in this image",
    contexts: ["image"]
  });

  chrome.contextMenus.create({
    id: "translate-page-images",
    title: "Translate all images on this page",
    contexts: ["page"]
  });
});

// ---------- Context menu handler ----------
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) return;

  if (info.menuItemId === "translate-image" && info.srcUrl) {
    chrome.tabs.sendMessage(tab.id, {
      type: "TRANSLATE_IMAGE",
      srcUrl: info.srcUrl
    });
  } else if (info.menuItemId === "translate-page-images") {
    chrome.tabs.sendMessage(tab.id, { type: "TRANSLATE_ALL_IMAGES" });
  }
});

// ---------- Message routing ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "FETCH_IMAGE") {
    fetchImageAsDataUrl(msg.url)
      .then(dataUrl => sendResponse({ ok: true, dataUrl }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; // async
  }

  if (msg.type === "TRANSLATE_TEXT") {
    translateText(msg.text, msg.sourceLang, msg.targetLang)
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg.type === "GET_SETTINGS") {
    chrome.storage.sync.get(null).then(s => sendResponse(s));
    return true;
  }
});

// ---------- Image fetching (bypasses page CSP for canvas tainting) ----------
async function fetchImageAsDataUrl(url) {
  const resp = await fetch(url, { credentials: "omit" });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const blob = await resp.blob();
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("FileReader failed"));
    reader.readAsDataURL(blob);
  });
}

// ---------- Translation engines ----------
async function translateText(text, sourceLang, targetLang) {
  const settings = await chrome.storage.sync.get(null);
  const engine = settings.engine || "google";

  if (!text?.trim()) return { translated: "", engine };

  switch (engine) {
    case "google":  return { translated: await google(text, sourceLang, targetLang), engine };
    case "deepl":   return { translated: await deepl(text, targetLang, settings.apiKeys.deepl), engine };
    case "openai":  return { translated: await openai(text, targetLang, settings.apiKeys.openai), engine };
    case "claude":  return { translated: await claude(text, targetLang, settings.apiKeys.claude), engine };
    default:        throw new Error(`Unknown engine: ${engine}`);
  }
}

// Free, unofficial Google Translate endpoint. No key. Rate-limited.
async function google(text, sourceLang, targetLang) {
  const sl = sourceLang || "auto";
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`Google: HTTP ${resp.status}`);
  const data = await resp.json();
  // Response shape: [[[translated, original, ...], ...], ...]
  return data[0].map(seg => seg[0]).join("");
}

async function deepl(text, targetLang, key) {
  if (!key) throw new Error("DeepL API key not set. Add it in Options.");
  const resp = await fetch("https://api-free.deepl.com/v2/translate", {
    method: "POST",
    headers: {
      "Authorization": `DeepL-Auth-Key ${key}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: new URLSearchParams({
      text,
      target_lang: targetLang.toUpperCase()
    })
  });
  if (!resp.ok) throw new Error(`DeepL: HTTP ${resp.status}`);
  const data = await resp.json();
  return data.translations[0].text;
}

async function openai(text, targetLang, key) {
  if (!key) throw new Error("OpenAI API key not set. Add it in Options.");
  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${key}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: `You are a translator. Translate the user's text into ${targetLang}. Reply with ONLY the translation, no quotes, no commentary.` },
        { role: "user", content: text }
      ],
      temperature: 0.2
    })
  });
  if (!resp.ok) throw new Error(`OpenAI: HTTP ${resp.status}`);
  const data = await resp.json();
  return data.choices[0].message.content.trim();
}

async function claude(text, targetLang, key) {
  if (!key) throw new Error("Claude API key not set. Add it in Options.");
  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 1024,
      messages: [
        { role: "user", content: `Translate the following text into ${targetLang}. Reply with ONLY the translation, no quotes, no preamble.\n\n${text}` }
      ]
    })
  });
  if (!resp.ok) throw new Error(`Claude: HTTP ${resp.status}`);
  const data = await resp.json();
  return data.content[0].text.trim();
}
