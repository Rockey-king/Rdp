// Content script
// Runs on every page. Handles user gestures on images, runs OCR via Tesseract,
// renders translated text overlay using bounding-box data.

(() => {
  // --- State ---
  let tesseractWorker = null;
  let currentOverlay = null;

  // --- Long-press detection (Android-friendly, scroll-safe) ---
  // Strategy: NEVER call preventDefault on touch events (would block scroll).
  // We only fire if the finger holds still on an image for LONG_PRESS_MS.
  // Any meaningful movement (>MOVE_TOLERANCE px) cancels — that means the
  // user is scrolling, swiping, or pinch-zooming, and we get out of the way.
  // All listeners are passive: true, so the browser's scroller is never
  // blocked waiting on our handler.
  let touchTimer = null;
  let touchTarget = null;
  let touchStartX = 0;
  let touchStartY = 0;
  const LONG_PRESS_MS = 600;
  const MOVE_TOLERANCE = 10; // px — generous, so jitter doesn't fire

  document.addEventListener("touchstart", (e) => {
    // Multi-touch (pinch zoom etc.) — never trigger
    if (e.touches.length !== 1) {
      cancelLongPress();
      return;
    }
    const img = e.target.closest("img");
    if (!img || img.naturalWidth < 100) return; // skip tiny icons

    touchTarget = img;
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;

    touchTimer = setTimeout(() => {
      // Fires only if no movement and finger still down.
      // We do NOT preventDefault — the gesture has already been claimed
      // as a stationary press, scrolling isn't happening anyway.
      if (touchTarget) translateImageElement(touchTarget);
      touchTarget = null;
    }, LONG_PRESS_MS);
  }, { passive: true });

  document.addEventListener("touchmove", (e) => {
    if (!touchTarget || !e.touches[0]) return;
    const dx = e.touches[0].clientX - touchStartX;
    const dy = e.touches[0].clientY - touchStartY;
    if (dx * dx + dy * dy > MOVE_TOLERANCE * MOVE_TOLERANCE) {
      cancelLongPress(); // user is scrolling — bail out
    }
  }, { passive: true });

  document.addEventListener("touchend",   cancelLongPress, { passive: true });
  document.addEventListener("touchcancel", cancelLongPress, { passive: true });

  function cancelLongPress() {
    clearTimeout(touchTimer);
    touchTimer = null;
    touchTarget = null;
  }

  // --- Message handlers from background ---
  chrome.runtime.onMessage.addListener(async (msg) => {
    if (msg.type === "TRANSLATE_IMAGE" && msg.srcUrl) {
      const img = findImageBySrc(msg.srcUrl);
      if (img) translateImageElement(img);
    } else if (msg.type === "TRANSLATE_ALL_IMAGES") {
      const imgs = Array.from(document.images).filter(i => i.naturalWidth > 200);
      for (const img of imgs) await translateImageElement(img);
    }
  });

  function findImageBySrc(src) {
    return Array.from(document.images).find(i => i.src === src || i.currentSrc === src);
  }

  // --- Main pipeline ---
  async function translateImageElement(img) {
    showStatus(img, "Loading…");
    try {
      const settings = await sendBg({ type: "GET_SETTINGS" });

      // 1. Get image as data URL via background (avoids CORS canvas taint)
      const { ok, dataUrl, error } = await sendBg({
        type: "FETCH_IMAGE",
        url: img.currentSrc || img.src
      });
      if (!ok) throw new Error(error || "Image fetch failed");

      showStatus(img, "Reading text…");

      // 2. OCR with Tesseract
      const ocrResult = await runOcr(dataUrl, settings.ocrLang || "eng");
      if (!ocrResult.words.length) {
        showStatus(img, "No text found", 2000);
        return;
      }

      showStatus(img, "Translating…");

      // 3. Group words into lines, translate each line
      const lines = groupWordsIntoLines(ocrResult.words);
      for (const line of lines) {
        const text = line.words.map(w => w.text).join(" ");
        const result = await sendBg({
          type: "TRANSLATE_TEXT",
          text,
          sourceLang: settings.autoDetectSource ? "auto" : ocrToIso(settings.ocrLang),
          targetLang: settings.targetLang || "en"
        });
        line.translated = result.ok ? result.translated : `[err: ${result.error}]`;
      }

      // 4. Render overlay
      hideStatus(img);
      renderOverlay(img, ocrResult, lines);
    } catch (err) {
      console.error("[LensTranslator]", err);
      showStatus(img, `Error: ${err.message}`, 3000);
    }
  }

  // --- OCR via Tesseract.js ---
  async function runOcr(dataUrl, lang) {
    if (!window.Tesseract) {
      await loadScript(chrome.runtime.getURL("lib/tesseract.min.js"));
    }
    if (!tesseractWorker) {
      tesseractWorker = await Tesseract.createWorker(lang, 1, {
        workerPath: chrome.runtime.getURL("lib/tesseract-worker.min.js"),
        corePath:   chrome.runtime.getURL("lib/tesseract-core.wasm.js"),
        langPath:   chrome.runtime.getURL("lib/lang-data"),
        logger: () => {}
      });
    }
    const { data } = await tesseractWorker.recognize(dataUrl);
    // data.words: [{ text, bbox: {x0,y0,x1,y1}, confidence }, ...]
    return {
      words: (data.words || []).filter(w => w.confidence > 50 && w.text.trim()),
      imageWidth: data.imageWidth || data.width,
      imageHeight: data.imageHeight || data.height
    };
  }

  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = res;
      s.onerror = rej;
      (document.head || document.documentElement).appendChild(s);
    });
  }

  // --- Group OCR words into lines by vertical proximity ---
  function groupWordsIntoLines(words) {
    if (!words.length) return [];
    const sorted = [...words].sort((a, b) => a.bbox.y0 - b.bbox.y0);
    const lines = [];
    let current = { words: [sorted[0]], y0: sorted[0].bbox.y0, y1: sorted[0].bbox.y1 };

    for (let i = 1; i < sorted.length; i++) {
      const w = sorted[i];
      const lineHeight = current.y1 - current.y0;
      const overlap = Math.min(current.y1, w.bbox.y1) - Math.max(current.y0, w.bbox.y0);
      if (overlap > lineHeight * 0.4) {
        current.words.push(w);
        current.y0 = Math.min(current.y0, w.bbox.y0);
        current.y1 = Math.max(current.y1, w.bbox.y1);
      } else {
        current.words.sort((a, b) => a.bbox.x0 - b.bbox.x0);
        lines.push(current);
        current = { words: [w], y0: w.bbox.y0, y1: w.bbox.y1 };
      }
    }
    current.words.sort((a, b) => a.bbox.x0 - b.bbox.x0);
    lines.push(current);

    // Compute line bbox
    for (const l of lines) {
      l.bbox = {
        x0: Math.min(...l.words.map(w => w.bbox.x0)),
        y0: l.y0,
        x1: Math.max(...l.words.map(w => w.bbox.x1)),
        y1: l.y1
      };
    }
    return lines;
  }

  // --- Render translated overlay positioned over the original image ---
  function renderOverlay(img, ocrResult, lines) {
    removeOverlay();

    const rect = img.getBoundingClientRect();
    const scaleX = rect.width  / ocrResult.imageWidth;
    const scaleY = rect.height / ocrResult.imageHeight;

    const wrap = document.createElement("div");
    wrap.className = "lt-overlay-wrap";
    wrap.style.position = "absolute";
    wrap.style.top  = (window.scrollY + rect.top)  + "px";
    wrap.style.left = (window.scrollX + rect.left) + "px";
    wrap.style.width  = rect.width + "px";
    wrap.style.height = rect.height + "px";
    wrap.style.zIndex = 2147483647;
    wrap.style.pointerEvents = "none";

    for (const line of lines) {
      const box = document.createElement("div");
      box.className = "lt-overlay-line";
      box.textContent = line.translated || "";
      box.style.position = "absolute";
      box.style.left = (line.bbox.x0 * scaleX) + "px";
      box.style.top  = (line.bbox.y0 * scaleY) + "px";
      box.style.width  = ((line.bbox.x1 - line.bbox.x0) * scaleX) + "px";
      box.style.minHeight = ((line.bbox.y1 - line.bbox.y0) * scaleY) + "px";
      // Auto-size text to fit
      const fontPx = Math.max(10, (line.bbox.y1 - line.bbox.y0) * scaleY * 0.85);
      box.style.fontSize = fontPx + "px";
      box.style.lineHeight = (fontPx * 1.1) + "px";
      wrap.appendChild(box);
    }

    // Tap-to-dismiss bar
    const bar = document.createElement("div");
    bar.className = "lt-overlay-bar";
    bar.textContent = "Tap to dismiss translation";
    bar.style.pointerEvents = "auto";
    bar.addEventListener("click", removeOverlay);
    wrap.appendChild(bar);

    document.body.appendChild(wrap);
    currentOverlay = wrap;

    // Reposition on scroll/resize
    const reposition = () => {
      if (!currentOverlay) return;
      const r = img.getBoundingClientRect();
      currentOverlay.style.top  = (window.scrollY + r.top)  + "px";
      currentOverlay.style.left = (window.scrollX + r.left) + "px";
      currentOverlay.style.width  = r.width  + "px";
      currentOverlay.style.height = r.height + "px";
    };
    window.addEventListener("scroll", reposition, { passive: true });
    window.addEventListener("resize", reposition, { passive: true });
  }

  function removeOverlay() {
    if (currentOverlay) {
      currentOverlay.remove();
      currentOverlay = null;
    }
  }

  // --- Status badge while processing ---
  function showStatus(img, text, autoHideMs) {
    hideStatus(img);
    const rect = img.getBoundingClientRect();
    const badge = document.createElement("div");
    badge.className = "lt-status";
    badge.textContent = text;
    badge.style.position = "absolute";
    badge.style.top  = (window.scrollY + rect.top + 8) + "px";
    badge.style.left = (window.scrollX + rect.left + 8) + "px";
    badge.style.zIndex = 2147483647;
    badge.style.pointerEvents = "none";
    document.body.appendChild(badge);
    img.dataset.ltStatus = badge.id = "lt-status-" + Date.now();
    if (autoHideMs) setTimeout(() => badge.remove(), autoHideMs);
  }

  function hideStatus(img) {
    const id = img.dataset.ltStatus;
    if (id) document.getElementById(id)?.remove();
  }

  // --- Helpers ---
  function sendBg(msg) {
    return new Promise(res => chrome.runtime.sendMessage(msg, res));
  }

  function ocrToIso(ocrLang) {
    const map = { eng: "en", jpn: "ja", chi_sim: "zh", chi_tra: "zh-TW", kor: "ko",
                  fra: "fr", deu: "de", spa: "es", ita: "it", rus: "ru", ara: "ar",
                  hin: "hi", por: "pt", tur: "tr", vie: "vi", tha: "th" };
    return map[ocrLang] || "auto";
  }
})();
